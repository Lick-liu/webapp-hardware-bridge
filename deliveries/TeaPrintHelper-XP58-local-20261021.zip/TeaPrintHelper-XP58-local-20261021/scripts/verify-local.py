"""Read-only package verification; --runtime also checks this Mac's installed helper.
Never starts/stops a process, changes config, submits or retries a print job.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parent.parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runtime',action='store_true');args=p.parse_args()
    checked=0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected,rel=line.split('  ',1)
        if sha(ROOT/rel)!=expected:raise ValueError('Checksum mismatch: '+rel)
        checked+=1
    result=dict(package_files_verified=checked,no_print_submitted=True)
    if args.runtime:
        app=Path('/Applications/Tea Print Helper.app');manifest=json.loads((ROOT/'manifest.json').read_text())
        for rel,expected in manifest['installed_app_files'].items():assert sha(app/rel)==expected,rel
        subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],check=True,capture_output=True)
        rows=[]
        for line in subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,command='],text=True).splitlines():
            fields=line.strip().split(None,2)
            if len(fields)==3 and fields[2].startswith(str(app/'Contents/runtime/Contents/Home/bin/java')+' ') and fields[2].endswith(' tigerworkshop.webapphardwarebridge.GUI'):rows.append(fields)
        assert len(rows)==1
        assert '-Dtea.print.macPos58RasterQueue=Xprinter_USB_Printer_Port' in rows[0][2].split()
        assert '-Dtea.print.macPos58ManualTear=true' in rows[0][2].split()
        with urlopen('http://127.0.0.1:12212/system/printer-mappings.json',timeout=4) as response:mappings=json.load(response)
        assert any(m.get('type')=='RECEIPT' and m.get('printerName')=='Xprinter USB Printer Port' and m.get('available') is True for m in mappings)
        uri=subprocess.check_output(['/usr/bin/lpstat','-h','localhost:631','-v','Xprinter_USB_Printer_Port'],text=True)
        assert manifest['usb_uri'] in uri
        assert sha(Path('/usr/libexec/cups/filter/rastertosnailep-pos'))==manifest['driver_sha256']
        unfinished=subprocess.check_output(['/usr/bin/lpstat','-h','localhost:631','-o','Xprinter_USB_Printer_Port'],text=True).strip()
        result.update(installed_files_match=True,signature_valid=True,actual_gui_flags_verified=True,
            receipt_mapping_available=True,driver_matches=True,queue_idle=not unfinished)
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
