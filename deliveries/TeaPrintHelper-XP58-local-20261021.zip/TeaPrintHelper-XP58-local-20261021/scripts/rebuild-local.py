"""Offline Java classpath rebuild/tests; no service start, USB, CUPS or printing.
Requires macOS/Python3; reuses the Java21 runtime and libraries in this delivery.
Does not invoke the unverified modular Gradle/installer path.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent.parent
APP=ROOT/'app/Tea Print Helper.app'
SOURCE=ROOT/'source'
TOOLS=ROOT/'build-tools'

def sha(data):return hashlib.sha256(data).hexdigest()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'rebuild-output')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    java=APP/'Contents/runtime/Contents/Home/bin/java'
    appdir=APP/'Contents/app'
    with zipfile.ZipFile(appdir/'webapp-hardware-bridge.jar') as z:metadata=json.loads(z.read('tea-local-build.json'))
    for rel,expected in metadata['source_sha256'].items():
        if sha((SOURCE/rel).read_bytes())!=expected:raise ValueError('Frozen source mismatch: '+rel)
    libs=sorted(p for p in appdir.glob('*.jar') if p.name not in ('webapp-hardware-bridge.jar','mac-launcher.jar'))
    cp=os.pathsep.join(map(str,[*libs,*sorted(TOOLS.glob('*.jar'))]))
    compiler=[str(java),'-javaagent:'+str(TOOLS/'lombok-1.18.34.jar')+'=ECJ','-jar',str(TOOLS/'ecj-3.41.0.jar'),'-17','-encoding','UTF-8']
    workspace=out/'test-workspace'
    shutil.copytree(SOURCE,workspace,symlinks=True)
    def run(argv,name,timeout=120,cwd=SOURCE):
        p=subprocess.run(list(map(str,argv)),cwd=cwd,capture_output=True,text=True,timeout=timeout)
        (out/(name+'.log')).write_text(p.stdout+p.stderr)
        if p.returncode:raise RuntimeError(name+' failed: '+(p.stdout+p.stderr)[-1500:])
        return p.stdout+p.stderr
    mainclasses=out/'main-classes';tests=out/'test-classes';launchers=out/'launcher-classes';launchtests=out/'launcher-test-classes'
    for p in (mainclasses,tests,launchers,launchtests):p.mkdir()
    mains=sorted(p for p in (SOURCE/'src/main/java').rglob('*.java') if p.name!='module-info.java')
    testsrc=sorted((SOURCE/'src/test/java').rglob('*Test.java'))
    launchsrc=[SOURCE/'scripts/macos'/name for name in ('MacLauncher.java','MacProtocolProbe.java','MacRawTransportProbe.java')]
    run([*compiler,'-cp',cp,'-d',mainclasses,*mains],'main-compile')
    run([*compiler,'-cp',str(mainclasses)+os.pathsep+cp,'-d',tests,*testsrc],'test-compile')
    names=['.'.join(p.relative_to(SOURCE/'src/test/java').with_suffix('').parts) for p in testsrc]
    testlog=run([java,'-Djava.awt.headless=true','-cp',os.pathsep.join(map(str,[tests,mainclasses]))+os.pathsep+cp,'org.junit.runner.JUnitCore',*names],'application-tests',cwd=workspace)
    count=int(re.search(r'OK \((\d+) tests\)',testlog).group(1));assert count==metadata['application_tests']==70
    run([*compiler,'-cp',str(mainclasses)+os.pathsep+cp,'-d',launchers,*launchsrc],'launcher-compile')
    run([*compiler,'-cp',str(launchers)+os.pathsep+cp,'-d',launchtests,ROOT/'build-support/MacLauncherCommandTest.java'],'launcher-test-compile')
    launchlog=run([java,'-Djava.awt.headless=true','-cp',os.pathsep.join(map(str,[launchtests,launchers]))+os.pathsep+cp,'org.junit.runner.JUnitCore','cn.teahouses.printhelper.MacLauncherCommandTest'],'launcher-tests')
    assert 'OK (4 tests)' in launchlog
    comparison={}
    for name,classes in [('webapp-hardware-bridge.jar',mainclasses),('mac-launcher.jar',launchers)]:
        template=appdir/name;dest=out/name
        with zipfile.ZipFile(template) as original,zipfile.ZipFile(dest,'w') as rebuilt:
            compiled={str(p.relative_to(classes)) for p in classes.rglob('*.class')}
            expected={i.filename for i in original.infolist() if i.filename.endswith('.class')}
            assert compiled==expected,(name,'class inventory mismatch')
            for info in original.infolist():
                content=original.read(info)
                if info.filename.endswith('.class'):
                    content=(classes/info.filename).read_bytes()
                    assert content==original.read(info),(name,info.filename,'class bytes mismatch')
                elif name=='webapp-hardware-bridge.jar' and not info.is_dir() and info.filename not in ('META-INF/MANIFEST.MF','tea-local-build.json'):
                    assert (SOURCE/'src/main/resources'/info.filename).read_bytes()==content,info.filename
                # Retain original archive metadata for a byte-reproducibility check.
                rebuilt.writestr(info,content)
        comparison[name]=dict(class_count=len(compiled),all_class_bytes_equal=True,
            jar_sha256=sha(dest.read_bytes()),accepted_jar_sha256=sha(template.read_bytes()),
            archive_bytes_equal=dest.read_bytes()==template.read_bytes())
    result=dict(application_tests=count,launcher_tests=4,source_to_installed_classes_verified=True,
        comparison=comparison,no_print_submitted=True,no_network=True,installed_app_modified=False,
        build='Java17 classpath ECJ with included Java21 and dependency jars; standard Gradle/installer unverified')
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
